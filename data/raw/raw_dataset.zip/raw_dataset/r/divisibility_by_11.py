even_sum = 0
odd_sum = 0

number = input()
n = list(map(int, number))

for i in range(len(n)):
    if i%2 == 0:
        even_sum += n[i]
    else:
        odd_sum += n[i]

if (even_sum - odd_sum)%11 == 0:
    print('Yes')
else:
    print('No')
    
   
