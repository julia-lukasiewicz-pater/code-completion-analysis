n = input()

count = 0
current = n[0]
for i in range(1,len(n)):
  if n[i] != current:
    count += 1
    current = n[i]

print(count + 1)


