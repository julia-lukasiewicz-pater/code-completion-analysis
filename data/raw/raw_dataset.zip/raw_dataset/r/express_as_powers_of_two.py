N = int(input())

i = 0
while N != 0:
  remainder = N%2
  if remainder == 1:
    print(2**i, end = ' ')
  i+=1
  N = N // 2

