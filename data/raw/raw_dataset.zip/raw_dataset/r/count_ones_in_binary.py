N = int(input())

count = 0
while N != 0:
  remainder = N%2
  if remainder == 1:
    count += 1
  N = N // 2

print(count)
