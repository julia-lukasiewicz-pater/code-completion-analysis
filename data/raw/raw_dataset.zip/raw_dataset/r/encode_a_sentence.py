vowels = {97,101,105,111,117,121}
consonants = set(range(97,123)) - vowels
consonants = list(map(chr,consonants))
text = input()
text_consonants = []
encoded = [*f'{text}']

for i, letter in enumerate(text):
  if letter.upper() in consonants:
    text_consonants.append(letter)
    
text_consonants = text_consonants[1:] + [text_consonants[0]]

for j, l in enumerate(text):
  if l.upper() in consonants:
    encoded[j] = text_consonants[0]
    text_consonants.pop(0)
    
print(''.join(encoded))


