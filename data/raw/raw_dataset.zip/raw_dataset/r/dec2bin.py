n = int(input())

lst = []
while n!=0:
	binNum = n%2
	lst.append(str(binNum))
	n = n//2
    
binary = ''.join(reversed(lst))
print(binary)
