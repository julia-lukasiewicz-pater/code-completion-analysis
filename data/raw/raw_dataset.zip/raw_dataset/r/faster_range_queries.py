n = int(input())
arr = list(map(int, input().split()))
q = int(input())

sums = [0]

for i, num in enumerate(arr):
  sums.append(num + sums[i])

for j in range(q):
  l, r = map(int,input().split())
  print(sums[r + 1] - sums[l])
