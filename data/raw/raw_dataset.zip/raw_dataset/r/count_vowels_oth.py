import itertools

s = input()
arr = [1 if c in ['a', 'e', 'i', 'o', 'u', 'y'] else 0 for c in s]
prefix_sums = [0] + list(itertools.accumulate(arr))
even_count = 1
ans = 0
for i in range(1, len(prefix_sums)):
    ans += even_count if prefix_sums[i]%2 == 1 else i-even_count
    even_count += prefix_sums[i]%2 == 0

print(ans)
