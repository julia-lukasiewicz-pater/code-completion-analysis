st = input()

vows = 'aeiouy'
counter = 0
how_many_vows = 0
for i in range(len(st) + 1):
    for j in range(len(st) + 1):
        subst = st[i:j]
        how_many_vows += len([letter for letter in subst if letter in vows])
        if how_many_vows%2 != 0:
            counter += 1
            how_many_vows = 0

print(counter)
