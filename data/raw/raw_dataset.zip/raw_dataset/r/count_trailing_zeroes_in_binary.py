A = int(input())

if A % 2 == 1:
    print(0)
else:
    counter = 0
    i = 0
    ith_bit = 0 
    while ith_bit != 1:
        counter += 1
        i += 1
        ith_bit = 1 if A & 2**i else 0
    
    print(counter)
