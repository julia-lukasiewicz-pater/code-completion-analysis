#Given an integer n, return the value of the rightmost bit and the value of the original number with its rightmost bit removed
n = int(input())

def isolate_rightmost_bit(n):
	if n%2 == 0:
		print(0)
	else:
		print(1)

	print(n//2)

isolate_rightmost_bit(n)
