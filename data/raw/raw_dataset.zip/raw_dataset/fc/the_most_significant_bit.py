#Given an integer n, calculate its most significant bit and print the corresponding power of 2
n = int(input())

def most_significant_bit(n):
	i = 0
	while n != 1:
		n = n >> 1
		i += 1
  

	print(f'{i} {2**i}')
most_significant_bit(n)
