#Given an array of n integers, find a contiguous subarray with the maximum sum of values
n = int(input())
arr = [0] + list(map(int, input().split()))

def max_sum_subarray(n, arr):
	current_sum = 0
	max_sum = 0

	for i, num in enumerate(arr):
		current_sum += num 
    
		if max_sum < current_sum:
			max_sum = current_sum
    
		if current_sum < 0:
			current_sum = 0

	return max_sum
print(max_sum_subarray(n, arr))

        
    

