#Given an integer n, compute the digital root of n by summing up all the digits of n and repeating that process on the result until reaching a single digit
n = input()

def sum_digits(n):
    sum = 0
    for num in n:
        sum += int(num)
    return str(sum)

sum = sum_digits(n)
while len(sum) > 1:
    sum = sum_digits(sum)

print(sum)
