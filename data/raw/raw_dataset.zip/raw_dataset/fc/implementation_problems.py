#Given all the numbers from 1 to n except one, find the missing number
n = int(input())
a = list(map(int, input().split()))

def find_missing_number(a):
	counter = 0
	for num in a:
		counter += num 

	summed = (n*(n+1))//2
	return summed - counter
	
print(find_missing_number(a))

