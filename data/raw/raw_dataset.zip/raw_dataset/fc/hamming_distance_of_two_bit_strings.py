#Given two bit-strings of the same length, calculate the hamming distance between these bit-strings
s1 = input().strip()
s2 = input().strip()

def hamming_distance(s1, s2):
	count = 0
	for i,j  in zip(s1, s2):
		if int(i) ^ int(j) == 1:
			count += 1 
	return count

print(hamming_distance(s1, s2))


