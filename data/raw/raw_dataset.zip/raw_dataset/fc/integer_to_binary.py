n = int(input())

def int2bin(n):
	output = []

	while n != 0:
		remainder = n%2
		output.append(remainder)
		n = n//2
	return output

result = int2bin(n)
for i in range(len(result)-1,-1, -1):
  print(result[i], end = '')
