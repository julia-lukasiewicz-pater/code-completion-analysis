#Given n bit-strings find the pair of bit-strings that has the minimum hamming distance
n = int(input())
n_list = []
for i in range(n):
  n_list.append(input())

def hamming_dist(str1, str2):
  count = 0
  for i,j in zip(str1,str2):
    if i != j:
      count += 1
  return count

result = len(n_list[0])
for i in range(len(n_list)):
  for j in range(len(n_list)):
    if i != j:
      ham_dist = hamming_dist(n_list[i],n_list[j])
      if ham_dist < result:
        result = ham_dist
print(result)
