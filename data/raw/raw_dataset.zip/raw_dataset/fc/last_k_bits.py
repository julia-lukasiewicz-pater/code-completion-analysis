#Given an integer n and an integer k, calculate the last k bits of the number n in its binary representation
n = int(input())
k = int(input())

def last_k_bits(n, k):
	for i in range(k-1, -1, -1):
		nth_bit = 1 if (1 << i) & n else 0
		print(nth_bit, end = '')

last_k_bits(n, k)

