#Given an array of numbers, check how many subarrays there are that sum up to exactly s
n, s = map(int, input().split())
arr = list(map(int, input().split()))

prev_s = {0: 1}
current_s = 0
count = 0

for num in arr:
    current_s += num
    if current_s - s in prev_s:
        count += prev_s[current_s - s]
    prev_s[current_s] = prev_s.get(current_s, 0) + 1


print(count)

