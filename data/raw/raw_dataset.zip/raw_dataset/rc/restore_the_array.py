#Given the number of array elements n and n integers separated by a space representing the elements of the prefix sum, calculate the initial array
n = int(input())
prefix_sums = list(map(int, input().split()))

print(prefix_sums[0], end = ' ')
for i in range(len(prefix_sums) - 1):
  print(prefix_sums[i+1] - prefix_sums[i], end = ' ')
