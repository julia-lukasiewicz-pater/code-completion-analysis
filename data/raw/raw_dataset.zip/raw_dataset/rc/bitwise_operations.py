#Given n integers, find 2 of those that after applying OR to them would result in the largest number
n = int(input())
arr = list(map(int,input().split()))

s = 0
for i in range(n):
  for j in range(n):
    result = arr[i] | arr[j]
    if result > s:
      s = result

print(s)
