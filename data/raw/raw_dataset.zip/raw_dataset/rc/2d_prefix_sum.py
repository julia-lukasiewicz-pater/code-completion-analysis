#Given a 2d array of numbers with r rows and c columns, calculate the 2d prefix sum of that array
r, c = map(int, input().split())
matrix = []
for i in range(r):
    row = list(map(int, input().split()))
    matrix.append(row)

prefix_matrix = [[0] * (c+1) for _ in range(r+1)]

for i in range(1,r+1):
    for j in range(1,c+1):
        prefix_matrix[i][j] = prefix_matrix[i - 1][j] + prefix_matrix[i][j-1] - prefix_matrix[i-1][j-1] + matrix[i-1][j-1]

for row in prefix_matrix[1:]:
    print(' '.join(map(str, row[1:])))
