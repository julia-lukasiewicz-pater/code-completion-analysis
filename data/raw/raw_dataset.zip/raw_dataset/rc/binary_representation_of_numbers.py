#Given a binary string s, compute the decimal equivalent of this string
s = list(map(int,list(input())))

actual = 0
current = 2

for ix in range(len(s)-2, -1,-1):
  actual += current * s[ix]
  current *= 2

actual += s[-1]
print(actual)
