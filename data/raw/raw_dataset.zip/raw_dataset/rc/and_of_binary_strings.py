#Given two binary strings A and B, compute the bitwise AND of these strings
A = input()
B = input()

result = ''
for i in range(len(A)):
  result += f'{int(A[i]) & int(B[i])}'

print(result)

