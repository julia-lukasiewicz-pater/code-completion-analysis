#Given an array of n integers, check it it's possible to slice the array into 3 non-empty parts so that these 3 parths have the same sum
n = int(input())
arr = list(map(int, input().split()))
total_sum = sum(arr)
target_sum = total_sum // 3   

if total_sum%3 == 0:

    count = 0
    partitions = 0
    current_sum = 0
    
    for num in arr:
        current_sum += num 
        if current_sum == target_sum:
            partitions += 1
            current_sum = 0
            count += 1
           
    if partitions == 3:
        print('Yes')
    else:
        print('No')
    
else:
    print('No')
    


        
        
    
