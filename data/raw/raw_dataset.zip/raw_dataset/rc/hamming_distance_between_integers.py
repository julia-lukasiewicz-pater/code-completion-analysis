#Given two integers a and b, calculate the hamming distance between these two
a, b = input().split()

result = bin(int(a) ^ int(b)).lstrip('0b')
count = 0
for i in result:
  if i == '1':
    count += 1
print(count)
