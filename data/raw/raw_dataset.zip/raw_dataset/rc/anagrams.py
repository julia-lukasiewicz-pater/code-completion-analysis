#Given a string s and n other strings, calculate how many of those are anagrams of the string s
s = input().lower()
n = int(input())

def count_letters(s):
    letters_s = dict()
    for i in s:
      if i != ' ':
        if i not in letters_s:
            letters_s[i] = 1
        else:
            letters_s[i] += 1
    return letters_s

letters_s = count_letters(s)

how_many_anagrams = 0
for j in range(n):
    anagram = input().lower()
    letters_anagram = count_letters(anagram)
    if letters_anagram == letters_s:
        how_many_anagrams += 1

print(how_many_anagrams)
