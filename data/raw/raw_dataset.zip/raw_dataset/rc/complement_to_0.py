#Given a positive integer n, compute the number of complement operations needed to perform in order to turn n into 0
n = int(input())

count = 0
while n!= 0:
  xor = n ^ (2 ** (n.bit_length()) - 1)
  
  count += 1
  n = xor

print(count)
