N = int(input())
shift = input()
k = int(input())

def bitwise_shifts(N, k, shift):
	if shift == 'left':
	  N =  N * (2**k)
	else:
	  N = N // (2**k)

	return N
print(bitwise_shifts(N, k, shift))

