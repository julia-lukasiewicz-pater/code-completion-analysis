import math
n = int(input())

def sum_all_divisors(n):
	sum_div = 0
	for i in range(1,math.floor(math.sqrt(n))+1):
	  if n%i == 0 and math.sqrt(n) != i:
	    sum_div += i
	    sum_div += n//i
	  elif n%i == 0 and math.sqrt(n) == i:
	      sum_div += i

	sum_div -= n

	if sum_div == n:
	  print('Yes')
	else:
	  print('No')
	  
sum_all_divisors(n)
