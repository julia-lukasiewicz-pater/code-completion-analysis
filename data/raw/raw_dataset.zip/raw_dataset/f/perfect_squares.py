from math import sqrt
n, q = map(int, input().split())
arr = list(map(int, input().split()))

def prefix_sum_of_sqrt(arr):
	prefix_sum = [0]
	squartes = []
	for i, num in enumerate(arr):
		if num >= 0 and sqrt(num) ** 2 == num:
			squartes.append(1)
		else:
			squartes.append(0)
		
		prefix_sum.append(squartes[i] + prefix_sum[i])
	return prefix_sum
    
result_prefix_sum = prefix_sum_of_sqrt(arr)
for i in range(q):
	l, r = map(int, input().split())
	print(result_prefix_sum[r+1] - result_prefix_sum[l])
