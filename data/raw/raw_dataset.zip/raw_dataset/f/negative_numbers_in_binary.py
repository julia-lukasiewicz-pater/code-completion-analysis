b = input()

def calculate_negative_and_represent_in_77_bits(b):

	b = b.zfill(77)
	b = ''.join(['1' if bit == '0' else '0' for bit in b])
	b = int(b,2) + 1
	return bin(b)[2:].zfill(77)
	
print(calculate_negative_and_represent_in_77_bits(b))


