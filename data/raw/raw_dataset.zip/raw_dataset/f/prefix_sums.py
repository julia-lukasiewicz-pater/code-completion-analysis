n = int(input())
arr = list(map(int, input().split()))

def prefix_sum(arr):
	current = 0
	for i, num in enumerate(arr):
		print(num + current, end = ' ')
		current += num

prefix_sum(arr)
