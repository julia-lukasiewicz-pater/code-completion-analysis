N = int(input())
rows = []
cols = []
for n in range(N):
    coords = list(map(int, input().split()))
    rows.append(coords[0])
    cols.append(coords[1])

def check_if_any_two_queens_attack_each_other(N):
    for i in range(N):
        for j in range(N):
            if i != j:
                if abs(rows[i] - rows[j]) + abs(cols[i] - cols[j]) <= 2:
                    return('Yes')
                
    return('No')
    
print(check_if_any_two_queens_attack_each_other(N))
