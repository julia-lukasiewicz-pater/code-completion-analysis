n, k = map(int, input().split())
permutation = list(map(int, input().split()))

def permutation_game(n,k,permutation):
    position = 0
    visited = {}

    for step in range(k):
        if position in visited:
            cycle_start = visited[position]
            cycle_end = step
            
            if cycle_start != -1:
                remaining_steps = (k - cycle_start) % (cycle_end - cycle_start)
                for _ in range(remaining_steps):
                    position = permutation[position]
            
            break
        visited[position] = step
        position = permutation[position]  
    return position

print(permutation_game(n, k, permutation))
