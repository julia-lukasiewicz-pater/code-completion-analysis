word = input()

def turn_singular_into_plural(word):
	consonants = 'bcdfghjklmnpqrstvwxz'
	vows = 'aeiyou'

	if word[-2:] in ['ss', 'sh', 'ch']:
		word += 'es'
	elif word[-1:] in ['s', 'x','z']:
		word += 'es'
	elif word[-1:] == 'y':
		if word[-2:-1] in consonants:
			word = word[:-1] + 'ies'
		elif word[-2:-1] in vows:
			word += 's'
	else:
		word += 's'

	return word

print(turn_singular_into_plural(word))
