n = int(input())
a = list(map(int,input().split()))
b = list(map(int,input().split()))

def slice_and_swap(a, b):
	var = 0
	for i in range(len(a)):
	  if b[i:] + b[:i] == a:
	    print('Yes')
	    var += 1
	    break
	if var == 0:
	  print('No')
	    
slice_and_swap(a, b)
