def dec2bin(n):
  b = []
  while n != 0:
    remainder = n%2
    b.append(str(remainder))
    n = n //2
  return ''.join(list(reversed(b)))

n = int(input())
bin_rep = dec2bin(n)
negation = bin_rep.translate(str.maketrans({'1':'0', '0':'1'}))
print(negation)

